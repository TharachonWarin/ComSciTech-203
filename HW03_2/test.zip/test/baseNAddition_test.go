package test

import (
	"reflect"
	"testing"
)

type testCase struct {
	function interface{}
	inputs   []interface{}
	expected []interface{}
}

func runTests(t *testing.T, cases []testCase) {
	for _, c := range cases {
		inputs := make([]reflect.Value, len(c.inputs))
		for i, input := range c.inputs {
			inputs[i] = reflect.ValueOf(input)
		}

		// Call the function with reflect
		results := reflect.ValueOf(c.function).Call(inputs)
		resultInterfaces := make([]interface{}, len(results))
		for i, result := range results {
			resultInterfaces[i] = result.Interface()
		}

		if !reflect.DeepEqual(resultInterfaces, c.expected) {
			t.Errorf("For function %v with inputs %v, expected %v, got %v",
				reflect.ValueOf(c.function), c.inputs, c.expected, resultInterfaces)
		}
	}
}

func TestFunctions(t *testing.T) {
	testCases := []testCase{
		{
			function: baseNAddition,
			inputs:   []interface{}{"11.01", "1.1", 2},
			expected: []interface{}{"100.11"},
		},
		{
			function: baseNAddition,
			inputs:   []interface{}{"18.50", "10.2", 10},
			expected: []interface{}{"28.70"},
		},
		{
			function: baseNAddition,
			inputs:   []interface{}{"11", ".95", 10},
			expected: []interface{}{"11.95"},
		},
		{
			function: baseNAddition,
			inputs:   []interface{}{"10.01", ".11", 2},
			expected: []interface{}{"11.00"},
		},
		{
			function: baseNAddition,
			inputs: []interface{}{"0101", "1011", 2},
			expected: []interface{}{"10000"},
		},
		{
			function: baseNAddition,
			inputs: []interface{}{"0.10", "0.10", 10},
			expected: []interface{}{"0.20"},
		},
	}

	runTests(t, testCases)
}
